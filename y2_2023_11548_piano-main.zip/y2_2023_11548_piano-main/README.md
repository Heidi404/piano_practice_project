# Piano

## Checkpoint2 

## Current properties

I have implemented the keyboard and the staff. The keyboard keys change color when clicked and the name of the key appears next to the keyboard.

A staff window appears above the keyboard and the notes played appear in the staff. All the notes are quarter notes (for now) so there are 4 of them in a bar. Currently all the notes appear in the same y position. 

## Instructions

The program does function. Once you run the program, a playable keyboard opens. The sound is not yet implemented.

## Schedule

So far I have worked on the project less than what I initially planned. I should have more time to work on it in the coming weeks. I am still confident that I'll be able to finish the project on time. 

## Other

So far I have not encountered any larger issues. I might have to change the original plan regarding the extra features. I'll have to see how much time I have left once the core program is finished.
